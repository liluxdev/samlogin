<?php

defined('_JEXEC') or die;
jimport('joomla.application.component.controlleradmin');

class SAMLoginControllerDiscojuice extends SAMLoginController {

    public function display($cachable = false) {
        parent::display($cachable);
    }

    
}

