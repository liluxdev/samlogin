<?php


// no direct access
defined('_JEXEC') or die ;
?>
<b>Please close this window now</b>