<?php
// no direct access
defined('_JEXEC') or die ;

class SamloginViewLogin extends SAMLoginView
{

	function display($tpl = null)
	{
		$this->addViewVariables();
		$this->setPageTitle();
		$this->loadHelper('Samlogin');
		SamloginHelper::loadHeadData($this->params, 'component',"login");
		SamloginHelper::setUserData($this->user);
		$variables = SamloginHelper::setVariables($this->params);
		foreach ($variables as $key => $value)
		{
			$this->assign($key, $value);
		}
		$layout = ($this->user->guest) ? 'default' : 'authenticated';
		$this->setLayout($layout);
		$this->addTemplatePaths();
                
                $sess=  JFactory::getSession();
                if ($sess->get("sloErrMsg")){
                    JFactory::getApplication()->enqueueMessage($sess->get("sloErrMsg"),$sess->get("sloErrType"));
                }
                
                
		parent::display();
	}



	private function getParams()
	{
		if (version_compare(JVERSION, '1.6.0', 'ge'))
		{
			$application = JFactory::getApplication();
			$params = $application->getParams('com_samlogin');
		}
		else
		{
			$params = JComponentHelper::getParams('com_samlogin');
		}
		return $params;
	}

	private function addTemplatePaths()
	{
            	// Get params
		$params = $this->getParams();
                $loginPageMode=$params->get("loginpagemode","default");
                $params->set('template', $loginPageMode);
            
		// Get application
		$application = JFactory::getApplication();

	

		// Look for template files in component folders
		$this->addTemplatePath(JPATH_COMPONENT.'/templates/login');
		$this->addTemplatePath(JPATH_COMPONENT.'/templates/login/default');

		// Look for overrides in template folder (Component template structure)
		$this->addTemplatePath(JPATH_SITE.'/templates/'.$application->getTemplate().'/html/com_samlogin/templates/login');
		$this->addTemplatePath(JPATH_SITE.'/templates/'.$application->getTemplate().'/html/com_samlogin/templates/login/default');

		// Look for overrides in template folder (Joomla! template structure)
		$this->addTemplatePath(JPATH_SITE.'/templates/'.$application->getTemplate().'/html/com_samlogin/login/default');
		$this->addTemplatePath(JPATH_SITE.'/templates/'.$application->getTemplate().'/html/com_samlogin/login');

		// Look for specific Component theme files
		if ($params->get('template', 'default'))
		{
			$this->addTemplatePath(JPATH_COMPONENT.'/templates/login/'.$params->get('template', 'default'));
			$this->addTemplatePath(JPATH_SITE.'/templates/'.$application->getTemplate().'/html/com_samlogin/templates/login/'.$params->get('template', 'default'));
			$this->addTemplatePath(JPATH_SITE.'/templates/'.$application->getTemplate().'/html/com_samlogin/login/'.$params->get('template', 'default'));
		}
	}

	private function setPageTitle()
	{
		if (version_compare(JVERSION, '1.6.0', 'ge'))
		{
			$application = JFactory::getApplication();
			$params = $this->getParams();
			$title = $params->get('page_title');
			if ($application->getCfg('sitename_pagetitles', 0) == 1)
			{
				$title = JText::sprintf('JPAGETITLE', $application->getCfg('sitename'), $params->get('page_title'));
			}
			elseif ($application->getCfg('sitename_pagetitles', 0) == 2)
			{
				$title = JText::sprintf('JPAGETITLE', $params->get('page_title'), $application->getCfg('sitename'));
			}
			$document = JFactory::getDocument();
			$document->setTitle($title);
		}
	}

	private function addStyles()
	{
		$document = JFactory::getDocument();
		$params = $this->getParams();
		$application = JFactory::getApplication();
		if (JFile::exists(JPATH_SITE.'/templates/'.$application->getTemplate().'/html/com_samlogin/login/'.$params->get('template', 'default').'/css/style.css'))
		{
			$document->addStylesheet(JURI::root(true).'/templates/'.$application->getTemplate().'/html/com_samlogin/login/'.$params->get('template', 'default').'/css/style.css?v=0.7');
		}
		else
		{
			$document->addStylesheet(JURI::root(true).'/components/com_samlogin/templates/login/'.$params->get('template', 'default').'/css/style.css?v=0.7');
		}

	}

	private function addViewVariables()
	{
		$user = JFactory::getUser();
		$this->assignRef('user', $user);
		$params = $this->getParams();
		$this->assignRef('params', $params);
	}

}
