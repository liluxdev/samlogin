<br/>
<p class="SAMLoginMessageView">
<?php 
echo $this->message;
?>
</p>